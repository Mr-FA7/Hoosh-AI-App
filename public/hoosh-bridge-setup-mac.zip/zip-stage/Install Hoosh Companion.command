#!/bin/bash
# Hoosh Companion — one-click install (run from Terminal; bypasses “Not Opened” .app block)
set +e
export PATH="/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"
cd "$(dirname "$0")" || exit 1

SRC="$(pwd)/HooshCompanion.app"
DEST_DIR="$HOME/Applications"
DEST="$DEST_DIR/HooshCompanion.app"
BIN="$DEST/Contents/MacOS/HooshCompanion"

clear 2>/dev/null
echo ""
echo "  ╔══════════════════════════════════════╗"
echo "  ║     Hoosh Companion — Installer      ║"
echo "  ╚══════════════════════════════════════╝"
echo ""

# Clear download quarantine on everything in this volume / folder
xattr -cr "$(pwd)" >/dev/null 2>&1
xattr -dr com.apple.quarantine "$(pwd)" >/dev/null 2>&1

if [ ! -d "$SRC" ]; then
  echo "ERROR: HooshCompanion.app not found next to this installer."
  echo "Re-download HooshCompanionSetup.dmg from https://aihoosh.com"
  echo ""
  read -r -p "Press Enter to close…"
  exit 1
fi

mkdir -p "$DEST_DIR"
rm -rf "$DEST"
echo "→ Installing to $DEST …"
/usr/bin/ditto "$SRC" "$DEST"
chmod +x "$BIN"
xattr -cr "$DEST" >/dev/null 2>&1
xattr -dr com.apple.quarantine "$DEST" >/dev/null 2>&1

# Re-sign ad-hoc after copy (quarantine strip can confuse Gatekeeper)
codesign --force --deep -s - "$DEST" >/dev/null 2>&1 || true

echo "→ Starting companion (via Terminal — avoids macOS “Not Opened” block)…"
echo ""

# CRITICAL: run the executable directly instead of `open Foo.app`
# `open` triggers Gatekeeper UI for unsigned apps; direct exec does not.
"$BIN"
STATUS=$?

echo ""
if [ $STATUS -eq 0 ]; then
  echo "✓ Done. Keep this window until companion finishes first-time setup,"
  echo "  then you can close it. Companion keeps running in the background."
else
  echo "Companion exited with code $STATUS."
  echo "If macOS still blocked something:"
  echo "  System Settings → Privacy & Security → Open Anyway"
  open "x-apple.systempreferences:com.apple.preference.security" 2>/dev/null \
    || open "x-apple.systempreferences:com.apple.Settings.PrivacySecurity.extension" 2>/dev/null \
    || true
fi
echo ""
read -r -p "Press Enter to close…"
exit $STATUS
