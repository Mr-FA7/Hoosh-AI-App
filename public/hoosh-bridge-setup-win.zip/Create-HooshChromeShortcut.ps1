# Desktop shortcut: start companion + open aihoosh.com (normal Chrome)
param([switch]$Silent)

$InstallDir = $PSScriptRoot
$Launcher = Join-Path $InstallDir 'Start-HooshBridge-Auto.bat'
if (-not (Test-Path $Launcher)) { exit 0 }

$WshShell = New-Object -ComObject WScript.Shell

function New-HooshShortcut([string]$Path) {
  if (-not $Path) { return }
  $dir = Split-Path $Path -Parent
  if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  $sc = $WshShell.CreateShortcut($Path)
  $sc.TargetPath = $Launcher
  $sc.WorkingDirectory = $InstallDir
  $sc.Description = 'Hoosh Local Bridge — companion + aihoosh.com'
  $sc.Save()
}

$desktop = [Environment]::GetFolderPath('Desktop')
$startMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Hoosh Local Bridge'
New-HooshShortcut (Join-Path $desktop 'Hoosh Local Bridge.lnk')
New-HooshShortcut (Join-Path $startMenu 'Hoosh Local Bridge.lnk')
$extInstaller = Join-Path $InstallDir 'Install-Extension-InYourChrome.ps1'
if (Test-Path $extInstaller) {
  $sc2 = $WshShell.CreateShortcut((Join-Path $startMenu 'Install extension in Chrome.lnk'))
  $sc2.TargetPath = 'powershell.exe'
  $sc2.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$extInstaller`""
  $sc2.WorkingDirectory = $InstallDir
  $sc2.Save()
}

if (-not $Silent) { Write-Host "Shortcuts updated" }
exit 0
