# One-time: install Hoosh extension into YOUR normal Chrome (default profile — no separate browser)
param([switch]$Silent)

$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName System.Windows.Forms | Out-Null

$InstallDir = $PSScriptRoot
$HooshDir = Join-Path $env:LOCALAPPDATA 'Hoosh'
$ExtDir = Join-Path $HooshDir 'extension'
$ExtId = 'ompmlkjlllkclhbgjklenapfaacfhmjk'
$Marker = Join-Path $HooshDir 'extension-in-default-chrome.ok'

function Find-Chrome {
  @(
    Join-Path ${env:ProgramFiles} 'Google\Chrome\Application\chrome.exe'
    Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'
    Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'
  ) | Where-Object { Test-Path $_ } | Select-Object -First 1
}

function Sync-Extension {
  $src = Join-Path $InstallDir 'extension'
  if (-not (Test-Path (Join-Path $src 'manifest.json'))) { throw "Extension missing in $src" }
  New-Item -ItemType Directory -Force -Path $ExtDir | Out-Null
  Copy-Item -Path (Join-Path $src '*') -Destination $ExtDir -Recurse -Force -Exclude 'key.pem'
}

function Show-Msg([string]$Text, [string]$Title = 'Hoosh Local Bridge', [string]$Buttons = 'OK', [string]$Icon = 'Information') {
  if ($Silent) { Write-Host $Text; return }
  [System.Windows.Forms.MessageBox]::Show($Text, $Title, $Buttons, $Icon) | Out-Null
}

try {
  Sync-Extension
} catch {
  Show-Msg $_.Exception.Message 'Hoosh Local Bridge' 'OK' 'Error'
  exit 1
}

$Chrome = Find-Chrome
if (-not $Chrome) {
  Show-Msg 'Google Chrome not found. Install Chrome, then run this again.' 'Hoosh Local Bridge' 'OK' 'Error'
  exit 1
}

if ((Test-Path $Marker) -and -not $Silent) {
  $again = [System.Windows.Forms.MessageBox]::Show(
    "Extension was already installed in your Chrome.`n`nInstall again?",
    'Hoosh Local Bridge', 'YesNo', 'Question')
  if ($again -ne 'Yes') { exit 0 }
}

$running = Get-Process chrome -ErrorAction SilentlyContinue
if ($running) {
  $close = 'Yes'
  if (-not $Silent) {
    $close = [System.Windows.Forms.MessageBox]::Show(
      "Chrome must close once to add Hoosh Local Bridge to YOUR normal browser.`n`nClose all Chrome windows now?",
      'Hoosh Local Bridge', 'YesNo', 'Question')
  }
  if ($close -ne 'Yes') { exit 0 }
  $running | Stop-Process -Force
  Start-Sleep -Seconds 2
}

# Default Chrome profile (no --user-data-dir) = your normal browser with bookmarks/history
Start-Process -FilePath $Chrome -ArgumentList @(
  "--load-extension=`"$ExtDir`""
  "chrome://extensions/?id=$ExtId"
  'https://aihoosh.com/'
) | Out-Null

Set-Content -Path $Marker -Value (Get-Date -Format 'o') -Encoding UTF8

Show-Msg @"
Done — extension added to your normal Chrome.

• chrome://extensions should show Hoosh Local Bridge (On/Off toggle)
• From now on use Chrome normally — no special profile
• Keep companion running (desktop shortcut starts it + opens aihoosh.com)
"@

exit 0
