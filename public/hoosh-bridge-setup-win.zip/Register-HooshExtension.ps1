# Copy extension files + register hoosh-bridge:// protocol (does not fail installer)
$ErrorActionPreference = 'Continue'
$InstallDir = $PSScriptRoot
$HooshDir = Join-Path $env:LOCALAPPDATA 'Hoosh'
$ExtDir = Join-Path $HooshDir 'extension'
$LogFile = Join-Path $HooshDir 'install.log'

function Write-Log([string]$Message) {
  $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] $Message"
  try {
    New-Item -ItemType Directory -Force -Path $HooshDir | Out-Null
    Add-Content -Path $LogFile -Value $line
  } catch { }
  Write-Host $Message
}

try {
  $srcExt = Join-Path $InstallDir 'extension'
  if (-not (Test-Path (Join-Path $srcExt 'manifest.json'))) {
    throw "Extension files missing in $srcExt"
  }

  New-Item -ItemType Directory -Force -Path $ExtDir | Out-Null
  Copy-Item -Path (Join-Path $srcExt '*') -Destination $ExtDir -Recurse -Force -Exclude 'key.pem'

  $version = (Get-Content (Join-Path $ExtDir 'manifest.json') -Raw | ConvertFrom-Json).version

  $launcher = Join-Path $InstallDir 'Start-HooshBridge-Auto.bat'
  if (Test-Path $launcher) {
    New-Item -Path 'HKCU:\Software\Classes\hoosh-bridge' -Force | Out-Null
    Set-ItemProperty -Path 'HKCU:\Software\Classes\hoosh-bridge' -Name '(Default)' -Value 'URL:Hoosh Local Bridge'
    Set-ItemProperty -Path 'HKCU:\Software\Classes\hoosh-bridge' -Name 'URL Protocol' -Value ''
    New-Item -Path 'HKCU:\Software\Classes\hoosh-bridge\shell\open\command' -Force | Out-Null
    Set-ItemProperty -Path 'HKCU:\Software\Classes\hoosh-bridge\shell\open\command' -Name '(Default)' -Value "`"$launcher`""
  }

  & (Join-Path $InstallDir 'Create-HooshChromeShortcut.ps1') -Silent

  Write-Log "Extension files ready v$version at $ExtDir"
} catch {
  Write-Log "Register error: $($_.Exception.Message)"
}

exit 0
