# Start companion + open aihoosh.com in your normal browser
$ErrorActionPreference = 'Stop'
$InstallDir = $PSScriptRoot
$Marker = Join-Path $env:LOCALAPPDATA 'Hoosh\extension-in-default-chrome.ok'

& (Join-Path $InstallDir 'start-companion.cmd') | Out-Null

if (-not (Test-Path $Marker)) {
  & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $InstallDir 'Install-Extension-InYourChrome.ps1')
  exit $LASTEXITCODE
}

Start-Process 'https://aihoosh.com/'
exit 0
